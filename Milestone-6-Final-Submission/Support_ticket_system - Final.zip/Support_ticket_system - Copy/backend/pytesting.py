import pytest
import requests

BASE_URL = "http://127.0.0.1:5000/api"

# Test data
test_user_data = {
    "email": "testuser@example.com",
    "password": "password",
    "name": "Test User",
    "username": "testuser",
    "user_id": "123456",
    "role": "student"
}

test_ticket_data = {
    "title": "Test Ticket",
    "description": "This is a test ticket."
}

test_reply_data = {
    "text": "This is a test reply."
}

def test_register_user():
    response = requests.post(f"{BASE_URL}/register", json=test_user_data)
    print(response.text, "Status code = ",response.status_code)
    assert response.status_code == 201
    assert "User registered successfully" in response.text

def test_login_user():
    response = requests.post(f"{BASE_URL}/login", json={"email": test_user_data["email"], "password": test_user_data["password"]})
    print(response.text, "Status code = ",response.status_code)
    assert response.status_code == 200
    assert "token" in response.json()

def test_create_ticket():
    login_response = requests.post(f"{BASE_URL}/login", json={"email": test_user_data["email"], "password": test_user_data["password"]})
    token = login_response.json()["token"]
    headers = {"Authorization": f"Bearer {token}"}

    response = requests.post(f"{BASE_URL}/tickets", json=test_ticket_data, headers=headers)
    print(response.text, "Status code = ",response.status_code)
    assert response.status_code == 201
    assert "Ticket created successfully" in response.text

def test_submit_reply():
    login_response = requests.post(f"{BASE_URL}/login", json={"email": test_user_data["email"], "password": test_user_data["password"]})
    token = login_response.json()["token"]
    headers = {"Authorization": f"Bearer {token}"}

    # First, create a ticket to reply to
    create_ticket_response = requests.post(f"{BASE_URL}/tickets", json=test_ticket_data, headers=headers)
    ticket_id = create_ticket_response.json()["ticket_id"]

    # Submit a reply to the created ticket
    response = requests.post(f"{BASE_URL}/tickets/{ticket_id}/replies", json=test_reply_data, headers=headers)
    print(response.text, "Status code = ",response.status_code)
    assert response.status_code == 201
    assert "Reply submitted successfully" in response.text

def test_mark_ticket_resolved():
    login_response = requests.post(f"{BASE_URL}/login", json={"email": test_user_data["email"], "password": test_user_data["password"]})
    token = login_response.json()["token"]
    headers = {"Authorization": f"Bearer {token}"}

    # First, create a ticket to mark as resolved
    create_ticket_response = requests.post(f"{BASE_URL}/tickets", json=test_ticket_data, headers=headers)
    ticket_id = create_ticket_response.json()["ticket_id"]

    # Mark the created ticket as resolved
    response = requests.put(f"{BASE_URL}/tickets/{ticket_id}/resolve", headers=headers)
    print(response.text, "Status code = ",response.status_code)
    assert response.status_code == 200
    assert "Ticket marked as resolved" in response.text

#test_register_user()
#test_login_user()
#test_create_ticket()
#test_submit_reply()
#test_mark_ticket_resolved()
