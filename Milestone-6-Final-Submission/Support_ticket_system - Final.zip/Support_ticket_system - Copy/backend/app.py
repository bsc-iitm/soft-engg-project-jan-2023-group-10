from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_restful import Api, Resource
import jwt
import os
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
current_dir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] =  "sqlite:///"+os.path.join(current_dir,"users.sqlite3")
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_secret_key'
db = SQLAlchemy(app)
api = Api(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(80), nullable=False)
    name = db.Column(db.String(120), nullable=True)
    username = db.Column(db.String(120), unique=True, nullable=False)
    role = db.Column(db.String(80), nullable=False)

    def __repr__(self):
        return f'<User {self.email}>'
    
class Ticket(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref='tickets')
    resolved = db.Column(db.Boolean, default=False)
    likes = db.Column(db.Integer, default=0)

    def __repr__(self):
        return f'<Ticket {self.title}>'

class Reply(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref='replies')
    ticket_id = db.Column(db.Integer, db.ForeignKey('ticket.id'), nullable=False)
    ticket = db.relationship('Ticket', backref='replies')

    def __repr__(self):
        return f'<Reply {self.id}>'
    
class FAQ(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question = db.Column(db.String(250), nullable=False)
    answer = db.Column(db.Text, nullable=False)

    def __repr__(self):
        return f'<FAQ {self.question}>'
    
# db.create_all()

with app.app_context():
    db.create_all()

class Register(Resource):
    def post(self):
        email = request.json.get("email")
        password = request.json.get("password")
        name = request.json.get("name")
        username = request.json.get("username")
        role = request.json.get("role")
        print(role)
        if not email or not password or not role:
            return {"message": "Email, password, and role are required"}, 400

        # existing_user = User.query.filter_by(email=email).first()
        # if existing_user:
        #     return {"message": "User with this email already exists"}, 400

        user = User(email=email, password=password, name=name, username=username, role=role)
        db.session.add(user)
        db.session.commit()

        return {"message": "User registered successfully"}, 201

class Login(Resource):
    def post(self):
        email = request.json.get("email")
        password = request.json.get("password")

        if not email or not password:
            return {"message": "Email and password are required"}, 400

        user = User.query.filter_by(email=email).first()
        if not user or not password:
            return {"message": "Invalid email or password"}, 401

        token = jwt.encode({"user_id": user.id}, app.config['SECRET_KEY'], algorithm='HS256')
        print(token)
        return {"message": "Logged in successfully", "token": token}, 200
    
class CreateTicket(Resource):
    def post(self):
        token = request.headers.get("Authorization")
        # print(token)
        # if not token:
        #     return {"message": "Missing authorization header"}, 401

        # token = token.split(" ")[1]
        try:
            payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            return {"message": "Expired token"}, 401
        except jwt.InvalidTokenError:
            return {"message": "Invalid token"}, 401

        user_id = payload['user_id']
        title = request.json.get("title")
        description = request.json.get("description")

        if not title or not description:
            return {"message": "Title and description are required"}, 400

        ticket = Ticket(title=title, description=description, user_id=user_id)
        db.session.add(ticket)
        db.session.commit()

        return {"message": "Ticket created successfully",  "ticket_id": ticket.id}, 201

class SubmitReply(Resource):
    def post(self, ticket_id):
        token = request.headers.get("Authorization")
        if not token:
            return {"message": "Missing authorization header"}, 401

        token = token.split(" ")[1]
        try:
            payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            return {"message": "Expired token"}, 401
        except jwt.InvalidTokenError:
            return {"message": "Invalid token"}, 401

        user_id = payload['user_id']
        text = request.json.get("text")

        if not text:
            return {"message": "Text is required"}, 400

        ticket = Ticket.query.get(ticket_id)
        if not ticket:
            return {"message": "Ticket not found"}, 404

        reply = Reply(text=text, user_id=user_id, ticket_id=ticket_id)
        db.session.add(reply)
        db.session.commit()

        return {"message": "Reply submitted successfully"}, 201
    
class MarkTicketResolved(Resource):
    def put(self, ticket_id):
        token = request.headers.get("Authorization")
        if not token:
            return {"message": "Missing authorization header"}, 401

        token = token.split(" ")[1]
        try:
            payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            return {"message": "Expired token"}, 401
        except jwt.InvalidTokenError:
            return {"message": "Invalid token"}, 401

        user_id = payload['user_id']
        ticket = Ticket.query.get(ticket_id)
        if not ticket:
            return {"message": "Ticket not found"}, 404

        ticket.resolved = True
        db.session.commit()

        return {"message": "Ticket marked as resolved"}, 200
    
class ListTickets(Resource):
    def get(self):
        token = request.headers.get("Authorization")
        if not token:
            return {"message": "Missing authorization header"}, 401

        # token = token.split(" ")[1]
        try:
            payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            return {"message": "Expired token"}, 401
        except jwt.InvalidTokenError:
            return {"message": "Invalid token"}, 401

        tickets = Ticket.query.all()
        ticket_list = [
            {
                "id": ticket.id,
                "title": ticket.title,
                "description": ticket.description,
                "user_id": ticket.user_id,
                "resolved": ticket.resolved
            }
            for ticket in tickets
        ]

        return {"tickets": ticket_list}, 200
    
class LikeTicket(Resource):
    def post(self, ticket_id):
        token = request.headers.get("Authorization")
        if not token:
            return {"message": "Missing authorization header"}, 401

        token = token.split(" ")[1]
        try:
            payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            return {"message": "Expired token"}, 401
        except jwt.InvalidTokenError:
            return {"message": "Invalid token"}, 401

        ticket = Ticket.query.get(ticket_id)
        if not ticket:
            return {"message": "Ticket not found"}, 404

        ticket.likes += 1
        db.session.commit()

        return {"message": "Ticket liked successfully", "likes": ticket.likes}, 200
    
class CreateFAQ(Resource):
    def post(self):
        question = request.json.get("question")
        answer = request.json.get("answer")

        if not question or not answer:
            return {"message": "Question and answer are required"}, 400

        faq = FAQ(question=question, answer=answer)
        db.session.add(faq)
        db.session.commit()

        return {"message": "FAQ entry created successfully", "faq_id": faq.id}, 201
    
class ListFAQs(Resource):
    def get(self):
        faqs = FAQ.query.all()
        faq_list = [
            {
                "id": faq.id,
                "question": faq.question,
                "answer": faq.answer
            }
            for faq in faqs
        ]

        return {"faqs": faq_list}, 200
    
class UserDetails(Resource):
    def get(self):
        Authorization = request.headers.get("Authorization")
        try:
            payload = jwt.decode(Authorization, app.config['SECRET_KEY'], algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            return {"message": "Expired token"}, 401
        except jwt.InvalidTokenError:
            return {"message": "Invalid token"}, 401

        user_id = payload['user_id']
        print(user_id)
        user = User.query.filter_by(id = user_id).first()
        
        return {"user_details":{
            "username":user.username,
            "email":user.email,
            "role":user.role,
            "name":user.name,
        } }, 200
    

api.add_resource(Register, "/api/register")
api.add_resource(Login, "/api/login")
api.add_resource(CreateTicket, "/api/tickets")
api.add_resource(ListTickets, "/api/tickets")
api.add_resource(SubmitReply, "/api/tickets/<int:ticket_id>/replies")
api.add_resource(MarkTicketResolved, "/api/tickets/<int:ticket_id>/resolve")
api.add_resource(LikeTicket, "/api/tickets/<int:ticket_id>/like")
api.add_resource(CreateFAQ, "/api/faqs")
api.add_resource(ListFAQs, "/api/faqs")
api.add_resource(UserDetails, "/api/user_details")

if __name__ == "__main__":
    app.run(debug=True)
