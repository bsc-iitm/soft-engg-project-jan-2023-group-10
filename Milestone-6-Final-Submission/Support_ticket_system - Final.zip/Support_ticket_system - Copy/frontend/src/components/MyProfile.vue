<template>
    <NavBar v-bind:login=true></NavBar>
    <div class="card my-5 mx-5" style="min-height: 200px;">
    <div class="row g-0">
      <div class="col-md-4">
        <img src="../assets/Profile.jpg" class="img-fluid rounded-start" >
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h5 class="card-title">Name :  {{ name }}</h5>
          <br>
          <h5 class="card-title">Username :  {{ username }}</h5>
          <br>
          <h5 class="card-title">Email : {{ email }}</h5>
          <br>
          <h5 class="card-title">Role : {{ role }}</h5>
          <!-- <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p> -->
        </div>
      </div>
    </div>
  </div>
  </template>

  <script>

  
  export default {
   data(){
    return{
      username:"",
      email:"",
      name:"",
      role:"",
    }
    },
    methods:{
      user_details() {     
              fetch(
                  "http://127.0.0.1:5000/api/user_details",
                  {
                  method: "GET",
                  headers:{
                    "Authorization": localStorage.getItem("Authorization"),
                      "Content-Type":"application/json",
                      "Access-Control-Allow-Origin": "*",
                  },
                  }
                  ).then(function(response) {
                      return response.json()
                  }).then((res)=> {
                      console.log(res);
                      this.email = res.user_details.email
                      this.name = res.user_details.name
                      this.username = res.user_details.username
                      this.role = res.user_details.role
                  }).catch(function(error){
                      console.log('error',error)
                  });
          }
            
      },
      beforeMount(){
          this.user_details()
        }
          }
  
  

</script>

<style>
</style>