<template>
    <div>
      <NavBar  v-bind:login=true />
  
      
        <div class="row my-5">
          <div class="col-md-10">
            <h1 class="display-3 text-center ">FAQ - Frequently Asked Questions</h1>
          </div>
         
        </div>
  
        <div class="container mx-5 my-5" v-for="(faq,index) in faq_list" :key="index">
          <div class="card text-bg-info w-75 mb-3">
          <div class="card-body">
            <h5 class="card-title">{{index+1}}. {{ faq.question }}</h5>
            <p class="card-text">Ans. {{ faq.answer }}</p>
          </div>
        </div>
        </div>   
      
    </div>
  </template>
  
  <script>
  
  export default {
      data(){
    return{
      faq_list:[]
    }
   },
   methods:{
  
    faq(){
        fetch(
          "http://127.0.0.1:5000//api/faqs",
          {
          method: "GET",
          headers:{
              "Authentication-Token": localStorage.getItem("auth_token"),
              "Content-Type":"application/json",
              "Access-Control-Allow-Origin": "*",
          },
        }).then(function(response) {
          return response.json()
        }).then((res) => {
            console.log(res)
            res.faqs.forEach(e => {
              this.faq_list.push(e)
            });
           
        }).catch(function(error){
            console.log('error',error)
        });
      }, 
  
  
  },
  beforeMount(){
      this.faq()
    }
  }
  </script>
  
  <style scoped>
   .footer {
      /* position: absolute; */
      bottom: 10px;
  }
  
  </style>