<template>
    <div>
      <NavBar v-bind:login=false />
       
        <div class="container d-flex justify-content-center">
          <div class="row bigbox ">
          
            <div class="col align-self-center">
            
              <div class="row text-center">
                <h1>Create an account</h1>
              </div>
               <div v-show="flag" class="alert alert-danger  my-3 mx-3 text-center" style="height:auto" id="signup_error" role="alert">
                
              </div>
              <div class="row">
                <form @submit.prevent="signup()">
                  
                  <div class="form-floating mb-3">
                    <input  v-model="username" type="text" class="form-control" placeholder="username" required/>
                    <label for="floatingInput">Username</label>
                  </div>
                  <div class="form-floating mb-3">
                    <input  v-model="name" type="text" class="form-control" placeholder="Email" required/>
                    <label for="floatingInput">Full Name</label>
                  </div>
                  <div class="form-floating mb-3">
                    <input  v-model="email" type="email" class="form-control" placeholder="Email" required/>
                    <label for="floatingInput">Email address</label>
                  </div>
                  <div class="form-floating">
                    <input v-model="password" type="password" class="form-control" minlength="8" placeholder="Password" required/>
                    <label for="floatingPassword">Password</label><br>
                  </div>
                  <div class="form-floating mb-3">
                    <input  v-model="role" type="text" class="form-control" placeholder="Email" required/>
                    <label for="floatingInput">Role</label>
                  </div>
                    <!-- <div class="row">
                      <div class="col">
                        <div class="dropdown" >
                                      <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        Roll
                                      </button>
                                      <ul class="dropdown-menu" >
                                        <li><a class="dropdown-item" href="#">Student</a></li>
                                        <li><a class="dropdown-item" href="#">Support Staff</a></li>
                                        <li><a class="dropdown-item" href="#">Admin</a></li>
                                      </ul>
                                    </div>
                      </div>
                      <div class="col">
                        <h3>aa</h3>
                      </div>
                  </div>     -->
     
                
                  <button  class="btn btn-primary w-100 btn-md" >Create account</button>
                </form>
              </div>
              <div class="row text-center">
                <router-link to="/login">Already have an account? Log in here</router-link>
              </div>
        
        
            </div>
          </div>
        </div>
    </div>
    </template>
  
  <script>
  export default{
    data(){
        return{
            email:"",
            password:"",
            username:"",
            name:"",
            role:"",
            flag:false
        }      
    },
    methods : {
            signup() {  
            fetch(
              "http://127.0.0.1:5000/api/register",
                {
                method: "POST",
                headers:{
                    "Content-Type":"application/json",
                    "Access-Control-Allow-Origin": "*",
                },
                body: JSON.stringify({
                "username":this.username,
                "email": this.email,
                "password": this.password,
                "name": this.name,
                "role":this.role,
            }),
                }
            ).then(function(response) {
                return response.json()
            }).then((res)=> {
              console.log(res)
    
                  this.$router.push({name:'login'})    
            }).catch(function(error){
                this.flag=true
                console.log('error',error)
            });
        }
    }
  }
  </script>
  
  <style scoped>
    .bigbox{
      max-width: 600px;
      min-width: 400px;
      min-height: 600px;
      
    }
    .row{
      padding: 10px 10px;
    }
    .alert {
    margin-bottom: 1px;
    height: 40px;
    
    line-height:40px;
    padding:0px 10px;
    }
  
    input {
    cursor: pointer;
    width: 100% ;
    height:20%;
  }
  </style>