<template>
  <NavBar v-bind:login=true></NavBar>
  <div class="div" v-for="(ticket,index) in ticket" :key="index">
    <div class="card my-5 mx-5"> 
  <h5 class="card-header">Ticket No: #{{ticket.id}}</h5>
  <div class="card-body">
    <h5 class="card-title">{{ticket.title}}</h5>
    <p class="card-text">{{ticket.description}}</p>
  </div>
</div>
  </div>
</template>

   <script>
export default {
    data(){
     return{
       ticket:[]
   
     }
     },
     methods:{
       check_login(){
         if (localStorage.getItem('Authorization')){
           this.login_flag=true
         }
       },
   
   
       tickets(){
         fetch(
           "http://127.0.0.1:5000/api/tickets",
           {
           method: "GET",
           headers:{
               "Authorization":localStorage.getItem("Authorization"),
               "Content-Type":"application/json",
               "Access-Control-Allow-Origin": "*",
           },
         }).then(function(response) {
           return response.json()
         }).then((res) => {
           console.log(res);
          this.ticket = res.tickets
           
         }).catch(function(error){
             console.log('error',error)
         });
       },
      
      
   
       
     
       },
       beforeMount(){
             this.tickets()
        
             this.check_login()
           }
   }
   </script>
   
   <style scoped>

   </style>