<template>
  <NavBar></NavBar>
    <div class="container d-flex justify-content-center">
          <div class="row bigbox ">
          
            <div class="col align-self-center">
              <div class="text-center">
                      <h2>Welcome to the Support Ticket System</h2>
              </div>
              
              
              <div class="row my-5">
                <form @submit.prevent="login_token">
                  <div class="form-floating mb-4 mx-5">
                    <input  v-model="email" type="email" class="form-control" id="floatingInput" placeholder="Email"  required>
                    <label for="floatingInput">Email address</label>
                  </div>
                  <div class="form-floating mx-5">
                    <input v-model="password" type="password" class="form-control" id="floatingPassword" placeholder="Password" required>
                    <label for="floatingPassword">Password</label><br>
                  </div>
                  <div class="col d-flex justify-content-center ">
                      <button class="btn btn-primary btn-lg  mx-5" >Login</button>
                      
  
                  </div>
                </form>
              </div>
           
                
            </div>
  
          </div>
        </div>
  
  </template>
  
  
  
  <script>
  
  export default {
   data(){
    return{
      email:"",
      password:""
    }
    },
    methods:{
      login_token() {     
              fetch(
                  "http://127.0.0.1:5000/api/login",
                  {
                  method: "POST",
                  headers:{
                      "Content-Type":"application/json",
                      "Access-Control-Allow-Origin": "*",
                  },
                  body: JSON.stringify({
                  "email": this.email,
                  "password": this.password
                  }),
                  }
                  ).then(function(response) {
                      return response.json()
                  }).then((res)=> {
                      console.log(res);
                      localStorage.setItem('Authorization', res.token);
                      this.$router.push({name:'homepage'})
                      
                  }).catch(function(error){
                      console.log('error',error)
                  });
          }
  
      },
          }
  
  
  </script>
  
  <style>
  .container {
  
    min-height: 100vh;
    min-width: 100vw;
  
  }
  
  </style>