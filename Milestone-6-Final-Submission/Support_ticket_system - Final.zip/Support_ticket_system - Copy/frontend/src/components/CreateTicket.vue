<template>
    <div>
        <NavBar  v-bind:login=true />
        <div class="container my-3">
            <form @submit.prevent="createpost">
                <div class="title my-3 shadow p-3 mb-5 bg-body rounded">
                    <textarea type="text" class="form-control" rows="1" id="title" placeholder="Type in title for the Ticket here..."  v-model="title"  required />
                </div>
              

                <div class="subtitle my-4 shadow p-3 mb-5 bg-body rounded">
                    <textarea type="text" rows="10" class="form-control" id="subtitle" placeholder="Tell us more about your issue..."  v-model="description"  required />
                </div>

                
                <div class="d-flex justify-content-center">
                    <button class="btn btn-success btn-lg" @click="checkallfield">Raise Ticket <i class="bi bi-check2-circle"></i></button>

                </div>
              

            </form>
            
        </div>
        

    </div>
</template>

<script>

export default {
data(){
    return{
       
        title:"",
        description:"",
        
    }
},
methods:{    
    createpost(){
          fetch(
              "http://127.0.0.1:5000/api/tickets",
              {
              method: "POST",
              headers:{
                "Authorization":localStorage.getItem("Authorization"),
                  "Content-Type":"application/json",
                  "Access-Control-Allow-Origin": "*",
              },
              body: JSON.stringify({
              "title":this.title,
              "description": this.description,
            }),
            }).then(function(response) {
              return response.json()
            }).then((res) => {
                console.log(res)
                this.$router.push({name:'homepage'})
            }).catch(function(error){
                console.log('error',error)
            });
    }
}
}
</script>

<style scoped>
.viewingimage{
    width: 100%;
    height: 300px;
    display: block;
    background-repeat:no-repeat ;
    cursor: pointer;
    margin: 10px auto 30px;
    background-size: cover;
    background-position: center center;
   
}
textarea[id=title] {
    background-color: none;
    border: none;
    /* color: white; */
    font-weight: bold;
    font-size: 50px ;
    padding: 16px 10px;
    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
    /* width: 100% ; */
    /* height:10%; */
    text-align: center;
}
textarea[id=subtitle]{
    background-color: none;
    border: none;
    /* color: white; */
    font-size: 30px ;
    padding: 16px 10px;
    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
    /* width: 100% ; */
    height:100%;
}

textarea[id=additionallinks] {
    background-color: none;
    border: none;
    /* color: white; */
    color: darkblue;
    padding: 16px 10px;
    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
    /* width: 100% ; */
    height:100%;
}

</style>