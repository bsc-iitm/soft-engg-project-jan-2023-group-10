import { createRouter, createWebHistory } from "vue-router"
import HomePage from "./components/HomePage"
import LoginPage from "./components/LoginPage"
import SignupPage from "./components/SignupPage"
import CreateTicket from "./components/CreateTicket"
import MyTickets from "./components/MyTickets"
import MyProfile from "./components/MyProfile"


const routes = [
  { path: '/login', 
    name:'login',
    component: LoginPage 
  },
  { 
    path: '/', 
    name:'homepage',
    component: HomePage
  },
  { 
    path: '/signup', 
    name:'signup',
    component: SignupPage
  },
  { 
    path: '/createticket', 
    name:'createticket',
    component: CreateTicket
  },
  { 
    path: '/mytickets', 
    name:'mytickets',
    component: MyTickets
  },
  { 
    path: '/myprofile', 
    name:'myprofile',
    component: MyProfile
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes, 
})


export default router;
